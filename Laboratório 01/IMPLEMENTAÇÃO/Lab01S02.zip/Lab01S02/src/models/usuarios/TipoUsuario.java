package models.usuarios;


public enum TipoUsuario{
    PROFESSOR,
    ALUNO,
    SECRETARIA;
}